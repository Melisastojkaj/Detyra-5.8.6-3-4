/** This program reads its input interactively and displays the result as a four-bar graph.*/
import javax.swing.*;
import java.awt.*;
   public class TestMakeChange
     {
       public static void main(String [] args) 
       {
         String dollar = JOptionPane.showInputDialog("Type the amount of dollars");
         int dollars = new Integer(dollar).intValue();
         String cent = JOptionPane.showInputDialog("Type the amount of cents");
         int cents = new Integer(cent).intValue();
         int money = (dollars * 100) + cents;
         int quarters = money / 25;
         int dimes = (money%25) / 10;
         int nickels = ((money%25)%10) / 5;
         int pennies = ((money%25)%10)%5;
         int scale_factor = 3;
          System.out.println("quarters = " + (money / 25));
          money = money % 25;
          System.out.println("dimes = " + (money / 10));
          money = money % 10;
          System.out.println("nickels = " + (money / 5));
          money = money % 5;
          System.out.println("pennies = " + money);
    
       MakeChange object = new MakeChange(699, 699);
        object.setTitle(JOptionPane.showInputDialog("Please type the title of the graph"));
        object.setAxes(250, 360, "100", 600);
        object.setBar1("Quarters", quarters * scale_factor, Color.red);
        object.setBar2("Dimes", dimes * scale_factor, Color.green);
        object.setBar3("Nickels", nickels * scale_factor, Color.yellow);
        object.setBar4("Pennies", pennies * scale_factor, Color.blue);
        
        }
      }