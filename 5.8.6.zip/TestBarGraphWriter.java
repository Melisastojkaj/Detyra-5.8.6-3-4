/** TestBarGraphWriter helps the user plot a bar graph of her own. */
import javax.swing.*;
import java.awt.*;
   public class TestBarGraphWriter  {
     public static void main(String [] args) {
      String input = JOptionPane.showInputDialog("Please type the value of the largest bar you will draw");
      int largest_value = new Integer(input).intValue();  // covert  data type String to int
      String bar1 = JOptionPane.showInputDialog("Please type the name of the first bar");
      String bar2 = JOptionPane.showInputDialog("Please type the name of the second bar"); 
      String bar3 = JOptionPane.showInputDialog("Please type the name of the third bar");
      String bar4 = JOptionPane.showInputDialog("Please type the name of the fourth bar"); 
      String bar5 = JOptionPane.showInputDialog("Please type the name of the fifth bar"); 
      String bar6 = JOptionPane.showInputDialog("Please type the name of the sixth bar");
      String numberOfdaysinJanuar = JOptionPane.showInputDialog("Please type the value of the first bar");
      int numOfDays = new Integer(numberOfdaysinJanuar).intValue();
      String numberOfdaysinFebruar = JOptionPane.showInputDialog("Please type the value of the second bar");
      int numOfDays1 = new Integer(numberOfdaysinFebruar).intValue();
      String numberOfdaysinMarch = JOptionPane.showInputDialog("Please type the value of the third bar");
      int numOfDays2 = new Integer(numberOfdaysinMarch).intValue();
      String numberOfdaysinApril = JOptionPane.showInputDialog("Please type the value of the fourth bar");
      int numOfDays3 = new Integer(numberOfdaysinMarch).intValue();
      String numberOfdaysinMay = JOptionPane.showInputDialog("Please type the value of the fifth bar");
      int numOfDays4 = new Integer(numberOfdaysinMay).intValue();
      String numberOfdaysinJune = JOptionPane.showInputDialog("Please type the value of the sixth bar");
      int numOfDays5 = new Integer(numberOfdaysinJune).intValue();
      int scale_factor = 3;
          
        BarGraphWriter object = new BarGraphWriter(599, 599);
         object.setTitle(JOptionPane.showInputDialog("Please type the title of your graph"));
         object.setAxes(30, 130, input, 100);
         object.setBar1(bar1, numOfDays * scale_factor, Color.red);
         object.setBar2(bar2, numOfDays1 * scale_factor, Color.green);
         object.setBar3(bar3, numOfDays2 * scale_factor, Color.yellow);
         object.setBar4(bar4, numOfDays3 * scale_factor, Color.green);
         object.setBar5(bar5, numOfDays4 * scale_factor, Color.blue);
         object.setBar6(bar6, numOfDays4 * scale_factor, Color.red);

      } 
    }