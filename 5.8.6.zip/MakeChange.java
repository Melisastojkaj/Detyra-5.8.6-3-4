/**  MakeChange has the methods needed to draw the MakeChange bar graph.  */
import java.awt.*;
import javax.swing.*;

 class MakeChange extends JPanel
{ 
     private int width, height, x_pos, y_pos;
     private int dist1 = 85;
     private int dist2 = 86;
     private Bar c = new Bar("",0,Color.black);
     Bar bar1 = c;
     Bar bar2 = c;
     Bar bar3 = c;
     Bar bar4 = c;
     Bar bar5 = c;
     Bar bar6 = c;
     JFrame my_frame;
 
  public MakeChange(int w, int h)
  {
    width = w;
    height = h;
    this.setBackground(Color.WHITE);
    my_frame = new JFrame();
    my_frame.getContentPane().add(this);
    my_frame.setSize(width, height);
    my_frame.setVisible(true);
  }

      public void setTitle(String title)
       {
           my_frame.setTitle(title);
       }
 
        public void setAxes(int x_pos, int y_pos, String top_label, int y_height)
          {
            // makes x_pos and y_pos available for other methods
             this.y_pos = y_pos; 
             this.x_pos = x_pos; 
             Graphics g = getGraphics();
              g.setColor(Color.BLACK);
              g.drawLine(x_pos, y_pos, x_pos + 275, y_pos);
              g.drawLine(x_pos, y_pos, x_pos, (y_pos - y_height - 800));
              g.drawString("0", 220, y_pos);
              g.drawString("50", 220, y_pos - 150);
              g.drawString("100", 220, y_pos - 300);
          }

     public void setBar1(String label, int height, Color c)
  {
    bar1 = new Bar(label,height,c);
    Graphics g = getGraphics();
    g.drawString(label, x_pos, y_pos + 13);
    g.setColor(c);
    g.fillRect(x_pos, y_pos - height,20, height);
    g.setColor(Color.BLACK);
    g.drawRect(x_pos, y_pos - height,20, height);
  }

  public void setBar2(String label, int height, Color c)
  {
    bar2 = new Bar(label,height,c);
    Graphics g = getGraphics();
    g.drawString(label, x_pos + dist2, y_pos + 13);
    g.setColor(c);
    g.fillRect(x_pos + dist1, y_pos - height,20, height);
    g.setColor(Color.BLACK);
    g.drawRect(x_pos + dist1, y_pos - height,20, height);
   }

  public void setBar3(String label, int height, Color c)
  {
    bar3 = new Bar(label,height,c);
    Graphics g = getGraphics();
    g.drawString(label, x_pos + dist2 * 2, y_pos + 13);
    g.setColor(c);
    g.fillRect(x_pos + dist1 * 2, y_pos - height,20, height);
    g.setColor(Color.BLACK);
    g.drawRect(x_pos + dist1 * 2, y_pos - height,20, height);
  }

  public void setBar4(String label, int height, Color c)
  {  bar4 = new Bar(label,height,c);
     Graphics g = getGraphics();
     g.drawString(label, x_pos + dist2 * 3, y_pos + 13);
     g.setColor(c);
     g.fillRect(x_pos + dist1 * 3, y_pos - height,20, height);
     g.setColor(Color.BLACK);
     g.drawRect(x_pos + dist1 * 3, y_pos - height,20, height);
  }
class Bar
   {
    private String s = "";
    private int h=0;
    private Color c =null;
    public Bar(String s, int h, Color c)
    {
      this.s = s;
      this.h = h;
      this.c = c;
    }
    public String getLabel(){
      return s;
    }
    public double getHeight(){
      return h;
    }
    public Color getColor(){
      return c; 
      }
      
   }
 }  



